﻿public static class Symbol
{
    public const string X = "X";
    public const string O = "O";
    public const string Random = "Random";
}